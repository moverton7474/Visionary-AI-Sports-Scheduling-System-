// TODO: idempotency helpers
