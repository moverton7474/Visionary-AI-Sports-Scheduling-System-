import "dotenv/config";
// TODO: initialize BullMQ queues + workers
console.log("workers placeholder");
