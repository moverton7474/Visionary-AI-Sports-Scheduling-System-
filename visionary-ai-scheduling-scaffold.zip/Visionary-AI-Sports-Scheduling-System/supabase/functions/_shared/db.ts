// Shared Supabase helpers for Edge Functions
// TODO: initialize supabase client with SERVICE_ROLE key for server-side operations
