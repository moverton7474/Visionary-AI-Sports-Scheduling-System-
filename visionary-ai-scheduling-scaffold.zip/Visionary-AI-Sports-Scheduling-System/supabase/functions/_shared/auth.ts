// TODO: auth + RBAC helpers (tenant + role)
