// TODO: feature flag helpers (tenant/role)
