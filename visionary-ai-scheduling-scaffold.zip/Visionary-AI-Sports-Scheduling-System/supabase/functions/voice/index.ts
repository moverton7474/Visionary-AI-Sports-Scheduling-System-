// Supabase Edge Function: Voice Agent Tool Endpoint (placeholder)
// Receives:
//  - intent
//  - validated slots
//  - user/tenant context
// Executes safe scheduling actions with confirmations and returns structured responses.
console.log("voice function placeholder");
