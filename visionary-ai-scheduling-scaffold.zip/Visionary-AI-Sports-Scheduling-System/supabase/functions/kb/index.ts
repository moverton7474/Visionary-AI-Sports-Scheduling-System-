// Supabase Edge Function: Knowledge Base query/ingest endpoint (placeholder)
// TODO: tenant-scoped retrieval with citations and safety
console.log("kb function placeholder");
