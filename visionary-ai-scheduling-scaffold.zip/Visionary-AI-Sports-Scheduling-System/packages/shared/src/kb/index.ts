// KB types and retrieval configs
export type KbCitation = { docId: string; chunkId: string; snippet: string };
export type KbAnswer = { answer: string; citations: KbCitation[] };
