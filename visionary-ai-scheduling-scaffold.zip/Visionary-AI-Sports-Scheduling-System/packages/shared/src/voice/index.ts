// Voice intents + tool contracts
export type VoiceIntent =
  | "calendar.query"
  | "calendar.create_request"
  | "calendar.approve"
  | "calendar.reschedule"
  | "calendar.cancel"
  | "kb.query";

export type ToolResponse = {
  speak: string;
  cards?: any[];
  requiresConfirmation?: boolean;
  confirmationPayload?: any;
};
