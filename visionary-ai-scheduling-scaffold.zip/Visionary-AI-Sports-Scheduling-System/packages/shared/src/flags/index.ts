// Unified feature flag API (provider-agnostic)
export type FlagContext = { tenantId: string; userId?: string; roles?: string[] };
export async function isEnabled(flag: string, ctx: FlagContext): Promise<boolean> {
  // TODO: implement Unleash/LaunchDarkly provider
  return true;
}
