// TODO: create browser Supabase client
