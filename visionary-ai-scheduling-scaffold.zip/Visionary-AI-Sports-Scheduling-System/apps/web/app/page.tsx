export default function Home() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Visionary AI Sports Scheduling System</h1>
      <p>Scaffold is in place. Build out Calendar, Voice Console, and Knowledge Base modules next.</p>
    </main>
  );
}
