export default function Page(){return <main style={padding:24}><h2>Calendar</h2><p>TODO</p></main>}
