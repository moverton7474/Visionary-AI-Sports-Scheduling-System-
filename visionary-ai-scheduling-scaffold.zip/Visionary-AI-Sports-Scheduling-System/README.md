# Visionary AI Sports Scheduling System

Multi-tenant, voice-first athletics facility scheduling system with:
- Supabase backend (Postgres/Auth/RLS/Edge Functions)
- Voice agent that can fully operate scheduling (read + actions with confirmations)
- Second Brain knowledge base (RAG) with tenant-scoped retrieval
- Queue-driven integrations (Teamworks / Microsoft 365 / Google Calendar)
- Enterprise SaaS controls (SSO-ready, audit, feature flags)

## Repo layout
- `apps/web` — Next.js web app (calendar UI + voice console + KB UI)
- `supabase` — migrations + Edge Functions
- `services/workers` — BullMQ workers for integrations + KB ingestion
- `packages/shared` — shared domain types/schemas, voice intents/tools, flags SDK
- `docs` — product docs, prompts, ADRs

## Quick start (local)
1. Install Node 20+ and pnpm
2. Copy `.env.example` to `.env` and fill values
3. Start dependencies:
   ```bash
   docker-compose up -d
   ```
4. Start Supabase locally (optional if you use hosted Supabase):
   ```bash
   npx supabase start
   ```
5. Install deps and run:
   ```bash
   pnpm install
   pnpm dev
   ```

## Notes
- This repo is a scaffold. See `docs/AI_STUDIO_PROMPT.md` for the build prompt to generate full modules.
