# Roadmap — Voice-First + Second Brain + Enterprise SaaS

## Phase 0 — Enterprise foundations (2–4 weeks)
- Tenant model (`tenants`, `tenant_members`, `roles`)
- RLS policies for tenant isolation
- Feature flag service integration + SDK
- Audit log schema (append-only)
- SSO strategy (staging + prod plan)

Exit:
- Tenant isolation proven with automated tests
- Flags can enable/disable major modules per tenant

---

## Phase 1 — Scheduling MVP + Voice “read-only navigation” (6–10 weeks)
Scheduling:
- Facilities/surfaces model
- Event CRUD + recurring events
- Approvals (draft → pending → approved/denied)
- Conflict engine v1 + explain modal
- iCal feeds

Voice agent v1 (navigation):
- “What’s on Field 1 today?”
- “Show availability for Basketball courts 2–6pm”
- “List pending approvals”
- Voice-controlled filtering and view changes

Second Brain v1 (read-only):
- ingest policies (PDF/Doc/Markdown)
- answer questions with citations/snippets
- tenant-scoped retrieval

Exit:
- Coaches can find availability and pending items via voice without touching UI
- Knowledge base answers common ops questions

---

## Phase 2 — Voice actions + guarded tool use (6–12 weeks)
Voice agent v2 (actions):
- create requests
- propose alternatives
- approve/deny
- reschedule/cancel with confirmations
- notify affected groups

Safety:
- confirm-before-commit flows
- “dry run” mode: simulate changes, then commit
- audit record includes agent intent + tool calls

Second Brain v2:
- “policy-driven scheduling” hints: buffers, priorities, closures
- curated “policy cards” with admin UI

Exit:
- Users can complete an end-to-end scheduling task via voice (request → approve → publish)

---

## Phase 3 — Integrations + enterprise controls (8–14 weeks)
- Queue + outbox fully hardened (DLQ, replay UI, metrics)
- Teamworks adapter + nightly reconciliation
- M365 Graph one-way publish; Google one-way publish
- Tenant-level integration config (per organization)
- Advanced reporting (utilization, conflicts, cycle time)

Exit:
- Reliable enterprise-grade sync and tenant-level admin controls

---

## Phase 4 — Enterprise SaaS packaging (ongoing)
- Billing + plans (per tenant)
- Organization admin console
- SSO (Okta/Azure/Google) hardening
- Optional data residency / isolated DB offerings
- Marketplace/integration catalog (API keys + scopes)
