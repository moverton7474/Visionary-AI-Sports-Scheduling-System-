# ADR 0004: Knowledge Base (RAG) Design

TBD
