# ADR 0003: Voice Agent Safety & Confirmations

TBD
