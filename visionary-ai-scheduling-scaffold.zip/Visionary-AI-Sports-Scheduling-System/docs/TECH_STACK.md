# Tech Stack — KSU Athletics Master Calendar (Supabase) + Voice Agent + Enterprise SaaS

> This version assumes: **Supabase backend**, **AI-first voice agent**, **Second Brain knowledge base (RAG)**, and a path to **multi-tenant enterprise SaaS**.

## Core Goals
- Full scheduling experience available via **voice** (hands-free navigation & actions).
- A “Second Brain” knowledge base that answers policy/process/facility questions and can take actions safely.
- Enterprise SaaS-ready: multi-tenant, SSO, audit, compliance, feature flags, and clean tenant isolation.

---

## Application Stack
### Frontend
- **Next.js (React + TypeScript)** — web app
- **UI**: TailwindCSS + shadcn/ui
- **State/Data**: TanStack Query + supabase-js
- **Calendar UI**: FullCalendar Resource Timeline (recommended) or custom grid
- **Voice UI**:
  - Web: Web Speech API (fallback) + streaming TTS
  - Preferred: a dedicated voice SDK (Twilio Voice / WebRTC) if you need phone dial-in

### Backend
- **Supabase**
  - Postgres (canonical data)
  - Auth (SSO-ready)
  - Row Level Security (RLS) for tenant isolation + RBAC
  - Edge Functions (TypeScript/Deno) for API endpoints, webhooks, and action execution
  - Realtime (optional) for live calendar updates

### Worker / Integration Layer
- **Queue** (recommended): **Upstash Redis + BullMQ** (Node.js TypeScript workers)
- Workers handle:
  - Teamworks sync
  - Microsoft Graph publish
  - Google Calendar publish
  - reconciliation & DLQ replay
  - embedding/indexing jobs for knowledge base

### AI / Voice Agent Stack
- **Conversation Orchestrator**: server-side “agent runtime” (Node or Edge Function)
- **STT/TTS**:
  - STT: Deepgram / Google STT / Azure STT (choose based on existing contracts)
  - TTS: ElevenLabs / Azure TTS / Google TTS
- **LLM + Tools**:
  - Tool calling enabled model
  - Strict action gating + confirmation flows
- **Memory**
  - Session memory: Redis (short-lived)
  - Long-term “Second Brain”: Postgres + vector store (see below)

### Knowledge Base (Second Brain RAG)
Two options:

**Option A (recommended with Supabase): pgvector**
- Store embeddings in Postgres using **pgvector**
- Keep tenant isolation in the same DB + RLS
- Pros: simplest infra
- Cons: not always fastest at massive scale (fine for most universities)

**Option B: Dedicated vector DB**
- Pinecone / Weaviate / Qdrant
- Pros: scale and performance
- Cons: extra infra + tenant isolation complexity

This project assumes **Option A**.

---

## Enterprise SaaS Architecture
### Multi-Tenancy Model (choose one)
**1) Single DB, shared schema + tenant_id (recommended initially)**
- All rows include `tenant_id`
- Enforce tenant isolation using **RLS**
- Pros: easiest to operate
- Cons: some customers prefer isolated DB

**2) Schema-per-tenant**
- Pros: stronger isolation
- Cons: operational complexity

**3) DB-per-tenant**
- Pros: strongest isolation, easiest compliance story
- Cons: most ops effort

Start with **1**; design so you can move strategic customers to 2/3 later.

### Identity / SSO
- Supabase Auth + SAML/OIDC (via Supabase Enterprise or an IdP proxy)
- Support:
  - Azure AD
  - Google Workspace
  - Okta (common for universities)

### Audit & Compliance
- Immutable audit log table (append-only)
- Admin reports + export
- PII minimization; configurable data retention

---

## Feature Flags (required)
Use a real feature flag system to support enterprise editions:
- **Unleash** (open-source) *or* **LaunchDarkly** (enterprise)
- Implement a thin internal `flags` library that supports:
  - tenant-level flags
  - role-based flags
  - percentage rollouts
  - kill switches (instant disable integrations)

Examples of flags:
- `voice_agent_enabled`
- `voice_agent_actions_enabled`
- `kb_rag_enabled`
- `outlook_addin_enabled`
- `two_way_calendar_sync_enabled`
- `teamworks_sync_enabled`
- `enterprise_sso_enabled`
- `advanced_reporting_enabled`

---

## Observability
- Logs: structured JSON
- Tracing: OpenTelemetry (optional)
- Error tracking: Sentry
- Metrics:
  - voice session success rate
  - tool/action failure rate
  - schedule conflict rate
  - sync latency per integration

---

## Security Must-Haves
- Webhook signature verification
- Rate limiting (especially on voice endpoints)
- Tenant isolation via RLS
- Action confirmation rules for destructive operations
- Least privilege service roles for integrations
