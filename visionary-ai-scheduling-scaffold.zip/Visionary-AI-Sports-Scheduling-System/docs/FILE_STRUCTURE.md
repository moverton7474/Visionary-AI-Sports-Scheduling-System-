# Suggested GitHub Repository Structure (Enterprise + Voice + KB)

```
master-calendar-saas/
  docs/
    TECH_STACK.md
    PRODUCT_DESCRIPTION.md
    ROADMAP.md
    PROMPTS/
      AI_STUDIO_PROMPT.md
    ADR/
  supabase/
    migrations/
    functions/
      api/
      voice/
      kb/
      webhooks/
      _shared/
  apps/
    web/
      app/
        (auth)/
        calendar/
        approvals/
        reports/
        kb/
        voice/
        admin/
      components/
      lib/
  services/
    workers/
      src/
        jobs/
          integrations/
          kb/
          reconciliation/
        lib/
  packages/
    shared/
      src/
        domain/
        schemas/
        permissions/
        flags/
        voice/
        kb/
  infra/
    terraform/            # optional
    deploy/
  scripts/
  .env.example
  docker-compose.yml
  README.md
  pnpm-workspace.yaml
```

## Where Voice Lives
- `apps/web/app/voice`: Voice console UI (mic, transcript, confirmations)
- `supabase/functions/voice`: tool endpoints used by the agent
- `packages/shared/src/voice`: intents, schemas, tool contracts
- `services/workers`: async tasks triggered by voice (notifications, bulk ops)

## Where the Second Brain Lives
- `apps/web/app/kb`: KB admin + search UI
- `supabase/functions/kb`: ingestion endpoints, query endpoint
- `packages/shared/src/kb`: chunking + retrieval config
- `services/workers/src/jobs/kb`: embedding pipeline
