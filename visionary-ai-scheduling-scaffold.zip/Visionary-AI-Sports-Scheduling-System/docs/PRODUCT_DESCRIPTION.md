# Product Description — KSU Athletics Master Calendar (Voice-First + Enterprise SaaS)

## Summary
KSU Athletics Master Calendar is a **facility and playing-surface scheduling system** with an **AI-first voice agent** and a **Second Brain knowledge base**. Users can manage the entire scheduling lifecycle—searching availability, creating requests, approving, rescheduling, and publishing—**through voice** without manual UI navigation.

The system is built to evolve into an **enterprise multi-tenant SaaS** that can be sold to other universities and organizations later.

---

## What Makes This Different
### 1) Voice-first operation (complete navigation)
Users can:
- “What’s open today between 3–5pm?”
- “Book Soccer Practice on Field 2, Tuesdays 4–6pm for 6 weeks”
- “Move the Volleyball practice to Court B and notify staff”
- “Show me conflicts for Saturday and propose alternatives”
- “Approve Coach Smith’s request and publish to Teamworks + Outlook”

Voice agent supports:
- **Hands-free navigation** (filters, views, drill-down)
- **Action execution** (create/edit/approve/cancel)
- **Explainability** (conflict reasons + fixes)
- **Safe confirmations** (read back changes before commit)

### 2) Second Brain knowledge base (RAG)
A searchable and conversational knowledge base that answers:
- facility rules and priorities
- practice policies and buffers
- maintenance schedules
- sport-specific constraints
- operational SOPs (rainout procedures, emergency closures)

The knowledge base is tenant-scoped and can include:
- PDFs, docs, policies, spreadsheets, emails (as allowed)
- structured “policy cards” authored by admins
- event history summaries (audit + rationale)

### 3) Enterprise SaaS-ready by design
- Multi-tenant with strict isolation
- SSO + RBAC
- Audit logging + exports
- Feature flags to enable/disable capabilities per tenant/edition

---

## Core Capabilities
- Master calendar UI + facility timeline
- Self-service booking + approvals
- Conflict engine + “why + fix” explainability
- iCal publishing feeds (facility/team)
- Integrations: Teamworks + Microsoft 365 + Google Calendar (queue-driven)
- Audit + utilization reporting
- Voice agent that can operate everything end-to-end

---

## Safety & Trust for Voice Actions
- Voice agent actions require:
  - identity verification (logged-in session or PIN for phone)
  - scoped permissions (RBAC)
  - confirmation for destructive actions
  - audit trail of “assistant did X for user Y”

---

## Success Metrics
- % of scheduling tasks completed via voice
- Reduction in double-bookings
- Approval cycle time reduction
- Sync reliability (time-to-consistency to Teamworks/Calendars)
- Adoption across teams/facilities
